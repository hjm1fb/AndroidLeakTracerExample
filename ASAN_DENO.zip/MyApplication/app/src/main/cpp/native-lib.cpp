#include <jni.h>
#include <string>
#include <android/bitmap.h>

extern "C" JNIEXPORT jstring JNICALL
Java_com_ufotosoft_demo_myapplication_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    char a[4];
    a[5] = 0; //Make an error
//    memset(a, 0, 5);
    return env->NewStringUTF(hello.c_str());
}
